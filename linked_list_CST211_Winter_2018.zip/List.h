#ifndef  LIST_H
#define  LIST_H

#include "ListNode.h"
#include "ForwardIterator.h"
#include "BackwardIterator.h"

template <class T>
class List
{
public:
	List() = default;
	~List() noexcept;

	List(List const& copy);
	List(List<T>&& copy) noexcept;

	List<T>& operator=(List<T> const& rhs);
	List<T>& operator=(List<T>&& rhs) noexcept;

	void Append(T const& data);
	void Prepend(T  const& data);

	void InsertBefore(T const& data, T const& before);
	void InsertAfter(T const& data, T const& after);

	void Extract(T const& data);
	void Purge();

	T& First();
	T& First() const;

	T& Last();
	T& Last() const;

	ListNode<T>* GetHead() const noexcept;
	ListNode<T>* GetTail() const noexcept;

	bool IsEmpty() const noexcept;
	ListNode<T>* FindNode(T const& data);

	ForwardIterator<T> ForwardBegin();
	ForwardIterator<T> ForwardEnd();
	BackwardIterator<T> BackwardBegin();
	BackwardIterator<T> BackwardEnd();

private:
	ListNode<T>* head_ = nullptr;
	ListNode<T>* tail_ = nullptr;
};

#endif

template<class T>
List<T>::~List() noexcept
{
	Purge();
}

template <class T>
void List<T>::Extract(T const& data)
{
	try
	{
		if (IsEmpty())
		{
			throw std::out_of_range("List is empty!");
		}
		auto node_to_extract{ FindNode(data) };

		if (node_to_extract == head_ && node_to_extract == tail_)
		{
			head_ = nullptr;
			tail_ = nullptr;
		}
		else if (node_to_extract == head_)
		{
			node_to_extract->GetNext()->SetPrevious(node_to_extract->GetPrevious());
			head_ = node_to_extract->GetNext();
		}
		else if (node_to_extract == tail_)
		{
			node_to_extract->GetPrevious()->SetNext(node_to_extract->GetNext());
			tail_ = node_to_extract->GetPrevious();
		}
		else
		{
			node_to_extract->GetPrevious()->SetNext(node_to_extract->GetNext());
			node_to_extract->GetNext()->SetPrevious(node_to_extract->GetPrevious());
		}

		delete node_to_extract;
	}
	catch (std::out_of_range& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
void List<T>::Purge()
{
	if (!IsEmpty())
	{
		while (head_ != nullptr)
		{
			auto next_node = head_->GetNext();
			delete head_;
			head_ = next_node;
		}
		tail_ = nullptr;
	}
}

template<class T>
T & List<T>::First()
{
	try
	{
		if (IsEmpty())
		{
			throw std::out_of_range("List is empty!");
		}
		return head_->GetData();
	}
	catch (std::out_of_range& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
T & List<T>::First() const
{
	try
	{
		if (IsEmpty())
		{
			throw std::out_of_range("List is empty!");
		}
		return head_->GetData();
	}
	catch (std::out_of_range& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
T & List<T>::Last()
{
	try
	{
		if (IsEmpty())
		{
			throw std::out_of_range("List is empty!");
		}
		return tail_->GetData();
	}
	catch (std::out_of_range& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
T & List<T>::Last() const
{
	try
	{
		if (IsEmpty())
		{
			throw std::out_of_range("List is empty!");
		}
		return tail_->GetData();
	}
	catch (std::out_of_range& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
ListNode<T>* List<T>::GetHead() const noexcept
{
	return head_;
}

template<class T>
ListNode<T>* List<T>::GetTail() const noexcept
{
	return tail_;
}

template<class T>
bool List<T>::IsEmpty() const noexcept
{
	auto result{ false };

	if (head_ == nullptr && tail_ == nullptr)
	{
		result = true;
	}

	return result;
}

template<class T>
ListNode<T>* List<T>::FindNode(T const& data)
{
	try
	{
		auto iterator{ head_ };
		ListNode<T>* found_data{ nullptr };

		while (iterator != nullptr)
		{
			if (iterator->GetData() == data)
			{
				found_data = iterator;
			}
			iterator = iterator->GetNext();
		}
		if (found_data == nullptr)
		{
			throw std::out_of_range("Before value not found in list!");
		}
		return found_data;
	}
	catch (std::out_of_range& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
List<T>::List(List const & copy)
{
	try
	{
		*this = copy;
	}
	catch (AdtException& e)
	{
		throw AdtException(e.what());
	}

}

template<class T>
List<T>::List(List<T>&& copy) noexcept
{
	*this = std::move(copy);
}

template<class T>
List<T>& List<T>::operator=(List<T> const & rhs)
{
	try
	{
		Purge();

		if (!rhs.IsEmpty())
		{
			auto iterator{ rhs.GetHead() };
			while (iterator != nullptr)
			{
				Append(iterator->GetData());
				iterator = iterator->GetNext();
			}
		}
		return *this;
	}
	catch (AdtException& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
List<T>& List<T>::operator=(List<T>&& rhs) noexcept
{
	Purge();

	head_ = rhs.GetHead();
	tail_ = rhs.GetTail();

	rhs.head_ = nullptr;
	rhs.tail_ = nullptr;

	return *this;
}

template<class T>
void List<T>::Append(T const & data)
{
	try
	{
		auto new_last_node = new ListNode<T>(data, tail_->GetNext(), tail_);
		tail_->SetNext(new_last_node);
		tail_ = new_last_node;

		if (head_ == nullptr)
		{
			head_ = new_last_node;
			tail_ = new_last_node;
		}
	}
	catch (std::bad_alloc& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
void List<T>::Prepend(T const & data)
{
	try
	{
		auto new_first_node = new ListNode<T>(data, head_, head_->GetPrevious());
		head_->SetPrevious(new_first_node);
		head_ = new_first_node;

		if (tail_ == nullptr)
		{
			head_ = new_first_node;
			tail_ = new_first_node;
		}

	}
	catch (std::bad_alloc& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
void List<T>::InsertBefore(T const & data, T const & before)
{
	try
	{
		auto iterator{ FindNode(before) };
		auto new_before_node = new ListNode<T>(data, iterator, iterator->GetPrevious());

		iterator->GetPrevious()->SetNext(new_before_node);
		iterator->SetPrevious(new_before_node);

		if (iterator == head_)
		{
			head_ = new_before_node;
		}
	}
	catch (AdtException& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
void List<T>::InsertAfter(T const & data, T const & after)
{
	try
	{
		auto iterator{ FindNode(after) };
		auto new_after_node = new ListNode<T>(data, iterator->GetNext(), iterator);

		iterator->GetNext()->SetPrevious(new_after_node);
		iterator->SetNext(new_after_node);

		if (iterator == tail_)
		{
			tail_ = new_after_node;
		}
	}
	catch (std::out_of_range& e)
	{
		throw AdtException(e.what());
	}
}

template<class T>
ForwardIterator<T> List<T>::ForwardBegin()
{
	ForwardIterator<T> result{ GetHead() };
	return result;
}

template<class T>
ForwardIterator<T> List<T>::ForwardEnd()
{
	ForwardIterator<T> result{ GetTail()->GetNext() };
	return result;
}

template<class T>
BackwardIterator<T> List<T>::BackwardBegin()
{
	BackwardIterator<T> result{ GetTail() };
	return result;
}

template<class T>
BackwardIterator<T> List<T>::BackwardEnd()
{
	BackwardIterator<T> result{ GetHead()->GetPrevious() };
	return result;
}

