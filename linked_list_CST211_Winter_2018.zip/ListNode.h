#ifndef LISTNODE_H
#define LISTNODE_H

#include "Node.h"

template <class T>
class ListNode : public Node<T>
{
public:
	ListNode() = default;
	ListNode(T const& data, ListNode<T>* next = nullptr, ListNode<T>* previous = nullptr) noexcept;
	~ListNode() = default;

	ListNode(ListNode const& copy) noexcept;
	ListNode(ListNode<T>&& copy) noexcept;

	ListNode<T>& operator=(ListNode<T> const& rhs) noexcept;
	ListNode<T>& operator=(ListNode<T>&& rhs) noexcept;

	ListNode<T>* GetNext() const noexcept;
	ListNode<T>* GetPrevious() const noexcept;

	void SetNext(ListNode<T> * const next) noexcept;
	void SetPrevious(ListNode<T> * const prev) noexcept;

private:
	ListNode<T>* next_ = nullptr;
	ListNode<T>* previous_ = nullptr;
};

#endif

template<class T>
ListNode<T>::ListNode(T const & data, ListNode<T>* next, ListNode<T>* previous) noexcept :
	next_{ next },
	previous_{ previous }
{
	this->SetData(data);
}

template<class T>
ListNode<T>::ListNode(ListNode const & copy) noexcept
{
	*this = copy;
}

template<class T>
ListNode<T>::ListNode(ListNode<T>&& copy) noexcept
{
	*this = std::move(copy);
}

template<class T>
ListNode<T>& ListNode<T>::operator=(ListNode<T> const & rhs) noexcept
{
	next_ = rhs.next_;
	previous_ = rhs.previous_;
	this->Setdata(rhs.GetData());
	return *this;
}

template<class T>
ListNode<T>& ListNode<T>::operator=(ListNode<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		next_ = std::move(rhs.next_);
		previous_ = std::move(rhs.previous_);
		this->std::move(Setdata(rhs.GetData()));
	}
	return *this;
}

template<class T>
ListNode<T> * ListNode<T>::GetNext() const noexcept
{
	auto const result{ nullptr };

	if (this != nullptr)
	{
		return next_;
	}
	return result;

}

template<class T>
ListNode<T> * ListNode<T>::GetPrevious() const noexcept
{
	auto const result{ nullptr };

	if (this != nullptr)
	{
		return previous_;
	}
	return result;
}

template<class T>
void ListNode<T>::SetNext(ListNode<T>* const next) noexcept
{
	if (this != nullptr)
	{
		next_ = next;
	}
}

template<class T>
void ListNode<T>::SetPrevious(ListNode<T>* const prev) noexcept
{
	if (this != nullptr)
	{
		previous_ = prev;
	}
}
