#ifndef FORWARDITERATOR_H
#define FORWARDITERATOR_H
#include "ListIterator.h"

template<class T>
class ForwardIterator : public ListIterator<T>
{
public:
	ForwardIterator() = default;
	~ForwardIterator() = default;

	ForwardIterator(ForwardIterator<T> const& copy) noexcept { *this = copy; }
	ForwardIterator(ForwardIterator<T> && copy) noexcept { *this = std::move(copy); }
	ForwardIterator(ListNode<T>* const node) noexcept { this->node_ = node; }

	ForwardIterator<T>& operator=(ForwardIterator<T> const& rhs) noexcept;
	ForwardIterator<T>& operator=(ForwardIterator<T> && rhs) noexcept;
	ListNode<T>* operator=(ListNode<T>* const rhs) noexcept override;

	ForwardIterator<T>& operator++() noexcept;
	ForwardIterator<T> operator++(int) noexcept;
	bool operator==(ForwardIterator<T>& rhs) noexcept { return this->node_ == rhs.node_; }
	bool operator!=(ForwardIterator<T>& rhs) noexcept { return this->node_ != rhs.node_; }

	void MoveNext() noexcept override;
	void Reset() noexcept override;
};

template<class T>
ForwardIterator<T>& ForwardIterator<T>::operator=(ForwardIterator<T> const & rhs) noexcept
{
	this->node_ = rhs.node_;
	this->done_ = rhs.done_;
	return *this;
}

template<class T>
ForwardIterator<T>& ForwardIterator<T>::operator=(ForwardIterator<T>&& rhs) noexcept
{

	if (this != &rhs)
	{
		node_ = std::move(rhs.node_);
		done_ = std::move(rhs.done_);
	}
	return *this;
}

template <class T>
ListNode<T>* ForwardIterator<T>::operator=(ListNode<T>* const rhs) noexcept
{
	ListNode<T>* result = rhs;
	return result;
}

template<class T>
ForwardIterator<T>& ForwardIterator<T>::operator++() noexcept
{
	this->MoveNext();
	return *this;
}

template<class T>
ForwardIterator<T> ForwardIterator<T>::operator++(int) noexcept
{
	auto result{ *this };
	++*this;
	return result;
}

template <class T>
void ForwardIterator<T>::MoveNext() noexcept
{
	if (this->node_ != nullptr)
	{
		this->node_ = this->node_->GetNext();
		this->done_ = false;
	}
	else
	{
		this->done_ = true;
	}
}

template <class T>
void ForwardIterator<T>::Reset() noexcept
{
	while (this->node_->GetPrevious() != nullptr)
	{
		this->node_ = this->node_->GetPrevious();
	}
	if (this->node_ == nullptr)
	{
		this->done_ = true;
	}
}

#endif
