#ifndef NODE_H
#define NODE_H

template <class T>
class Node
{
public:
	T & GetData() noexcept { return data_; }
	T GetData() const noexcept { return data_; }

	void SetData(T const& data) noexcept
	{
		if (&data_ != &data)
			data_ = data;
	}

protected:
	Node() = default;

	virtual ~Node() = 0;

	Node(T const& data) noexcept : data_{data} {}

	Node(Node const& copy) noexcept { *this = copy; }
	Node(Node<T>&& copy) noexcept { *this = std::move(copy); }

	Node<T>& operator=(Node<T> const& rhs) noexcept
	{
		data_ = rhs.data_;
		return *this;
	}

	Node<T>& operator=(Node<T>&& rhs) noexcept
	{
		if (this != &rhs)
			data_ = std::move(rhs.data_);

		return *this;
	}

private:
	T data_;
};

template<class T>
Node<T>::~Node() = default;

#endif
