#ifndef BACKWARDITERATOR_H
#define BACKWARDITERATOR_H
#include "ListIterator.h"

template<class T>
class BackwardIterator : public ListIterator<T>
{
public:
	BackwardIterator() = default;
	~BackwardIterator() = default;

	BackwardIterator(BackwardIterator<T> const& copy) noexcept { *this = copy; }
	BackwardIterator(BackwardIterator<T> && copy) noexcept { *this = std::move(copy); }
	BackwardIterator(ListNode<T>* const node) noexcept { this->node_ = node; }

	BackwardIterator<T>& operator=(BackwardIterator<T> const& rhs) noexcept;
	BackwardIterator<T>& operator=(BackwardIterator<T> && rhs) noexcept;
	ListNode<T>* operator=(ListNode<T>* const rhs) noexcept override;

	BackwardIterator<T>& operator++() noexcept;
	BackwardIterator<T> operator++(int) noexcept;
	bool operator==(BackwardIterator<T>& rhs) noexcept { return this->node_ == rhs.node_; }
	bool operator!=(BackwardIterator<T>& rhs) noexcept { return this->node_ != rhs.node_; }

	void MoveNext() noexcept override;
	void Reset() noexcept override;
};

template<class T>
BackwardIterator<T>& BackwardIterator<T>::operator=(BackwardIterator<T> const & rhs) noexcept
{
	this->node_ = rhs.node_;
	this->done_ = rhs.done_;
	return *this;
}

template<class T>
BackwardIterator<T>& BackwardIterator<T>::operator=(BackwardIterator<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		node_ = std::move(rhs.node_);
		done_ = std::move(rhs.done_);
	}
	return *this;
}

template <class T>
ListNode<T>* BackwardIterator<T>::operator=(ListNode<T>* const rhs) noexcept
{
	ListNode<T>* result = rhs;
	return result;
}

template<class T>
BackwardIterator<T>& BackwardIterator<T>::operator++() noexcept
{
	this->MoveNext();
	return *this;
}

template<class T>
BackwardIterator<T> BackwardIterator<T>::operator++(int) noexcept
{
	auto result{ *this };
	++*this;
	return result;
}

template <class T>
void BackwardIterator<T>::MoveNext() noexcept
{
	if (this->node_ != nullptr)
	{
		this->node_ = this->node_->GetPrevious();
		this->done_ = false;
	}
	else
	{
		this->done_ = true;
	}
}

template <class T>
void BackwardIterator<T>::Reset() noexcept
{
	while (this->node_->GetNext() != nullptr)
	{
		this->node_ = this->node_->GetNext();
	}
	if (this->node_ == nullptr)
	{
		this->done_ = true;
	}
}

#endif
